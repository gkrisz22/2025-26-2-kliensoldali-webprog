import { createSlice, type PayloadAction } from '@reduxjs/toolkit'
import type { RootState } from './store'

// Define a type for the slice state
export interface CounterState {
  value: number
}

// Define the initial state using that type
const initialState2: CounterState = {
  value: 0
}

// const [counter, setCounter] = useState(0);

export const counterSlice = createSlice({
  name: 'counter',
  // `createSlice` will infer the state type from the `initialState` argument
  initialState: initialState2,
  reducers: {
    increment: state => {
      state.value += 1
    },
    decrement: state => {
      state.value -= 1
    },
    // Use the PayloadAction type to declare the contents of `action.payload`
    incrementByAmount: (state, action: PayloadAction<number>) => {
      state.value += action.payload
    }
  }
})

/*
    UI -> Gombra kattintás -> dispatch() ->
    Action: 
    {
        type: "increment",
        payload: {
            username: "valaki",
            password: "12345"
        }
    }

    Reducers:
    switch(Action.type) {
        case "increment": 
            state.value += 1;
            break;
    }

    UI -> Selector(counter) -> console.log(counter)
*/

export const { increment, decrement, incrementByAmount } = counterSlice.actions

// Other code such as selectors can use the imported `RootState` type
export const selectCount = (state: RootState) => state.counter.value

export default counterSlice.reducer